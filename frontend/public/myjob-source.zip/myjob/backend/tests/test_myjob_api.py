"""MyJob API - Backend Tests"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

TEST_EMAIL = f"test_auto_{int(time.time())}@myjob.com"
TEST_PASSWORD = "TestPass123"
TEST_NAME = "Auto Test User"

@pytest.fixture(scope="module")
def auth_tokens():
    """Register and return tokens"""
    r = requests.post(f"{BASE_URL}/api/auth/register", json={
        "email": TEST_EMAIL, "password": TEST_PASSWORD, "name": TEST_NAME
    })
    assert r.status_code == 200, f"Register failed: {r.text}"
    data = r.json()
    return data["access_token"], data["refresh_token"]

@pytest.fixture(scope="module")
def headers(auth_tokens):
    return {"Authorization": f"Bearer {auth_tokens[0]}"}

# ── Auth Tests ──────────────────────────────────────────────────────────────

class TestAuth:
    def test_register_new_user(self):
        email = f"test_reg_{int(time.time())}@myjob.com"
        r = requests.post(f"{BASE_URL}/api/auth/register", json={
            "email": email, "password": "Pass123", "name": "Reg User"
        })
        assert r.status_code == 200
        data = r.json()
        assert "access_token" in data
        assert data["user"]["email"] == email

    def test_login_valid(self, auth_tokens):
        r = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_EMAIL, "password": TEST_PASSWORD
        })
        assert r.status_code == 200
        data = r.json()
        assert "access_token" in data
        assert data["user"]["email"] == TEST_EMAIL

    def test_login_invalid(self):
        r = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": "wrong@test.com", "password": "wrong"
        })
        assert r.status_code == 401

    def test_me_endpoint(self, headers):
        r = requests.get(f"{BASE_URL}/api/auth/me", headers=headers)
        assert r.status_code == 200
        data = r.json()
        assert data["email"] == TEST_EMAIL

# ── Applications Tests ───────────────────────────────────────────────────────

class TestApplications:
    app_id = None

    def test_create_application(self, headers):
        r = requests.post(f"{BASE_URL}/api/applications", headers=headers, json={
            "company": "TEST_Acme Corp", "role": "Software Engineer",
            "status": "Applied", "location": "Remote"
        })
        assert r.status_code == 200
        data = r.json()
        assert data["company"] == "TEST_Acme Corp"
        assert "id" in data
        TestApplications.app_id = data["id"]

    def test_list_applications(self, headers):
        r = requests.get(f"{BASE_URL}/api/applications", headers=headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_update_application(self, headers):
        assert TestApplications.app_id, "No app_id from create test"
        r = requests.put(f"{BASE_URL}/api/applications/{TestApplications.app_id}",
                         headers=headers, json={"status": "Interview"})
        assert r.status_code == 200
        assert r.json()["status"] == "Interview"

    def test_delete_application(self, headers):
        assert TestApplications.app_id, "No app_id from create test"
        r = requests.delete(f"{BASE_URL}/api/applications/{TestApplications.app_id}", headers=headers)
        assert r.status_code == 200

    def test_delete_nonexistent(self, headers):
        r = requests.delete(f"{BASE_URL}/api/applications/nonexistent-id", headers=headers)
        assert r.status_code == 404

# ── Analytics Tests ──────────────────────────────────────────────────────────

class TestAnalytics:
    def test_analytics_endpoint(self, headers):
        r = requests.get(f"{BASE_URL}/api/analytics", headers=headers)
        assert r.status_code == 200

# ── Chat Tests ───────────────────────────────────────────────────────────────

class TestChat:
    def test_chat_assistant_mode(self, headers):
        r = requests.post(f"{BASE_URL}/api/chat", headers=headers, json={
            "message": "Say hello in one word", "mode": "assistant"
        }, timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert "reply" in data or "response" in data or "message" in data

    def test_followups_endpoint(self, headers):
        r = requests.get(f"{BASE_URL}/api/followups", headers=headers)
        assert r.status_code == 200
