# MyJob — Career Intelligence Platform

## Stack
- Frontend: React 18 + Tailwind CSS + ShadCN UI
- Backend: FastAPI (Python 3.12)
- Database: MongoDB
- AI: OpenAI GPT-4o mini

## Features
- Job application tracker (CRUD + status)
- AI Resume Optimizer (ATS score + keyword analysis)
- Job URL scraper (import any job posting with AI)
- AI Career Assistant + Mock Interview mode
- Follow-up email generator
- Analytics dashboard
- XP/gamification system
- Browser Extension (Chrome Manifest V3)

## Quick Start

### Backend
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env   # edit with your keys
uvicorn server:app --reload --port 8001
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env   # set REACT_APP_BACKEND_URL=http://localhost:8001
npm start
```

### Chrome Extension
1. Open Chrome → chrome://extensions
2. Enable "Developer mode" (top right)
3. Click "Load unpacked" → select the `extension/` folder
4. Click the MyJob icon → Settings → enter your backend URL + auth token

## Deploy
- Frontend → Vercel (set REACT_APP_BACKEND_URL to your backend URL)
- Backend  → Railway (add all .env variables)
- Database → MongoDB Atlas (free tier)

## Environment Variables (Backend)
| Variable    | Description                          |
|-------------|--------------------------------------|
| MONGO_URL   | MongoDB connection string            |
| DB_NAME     | Database name                        |
| JWT_SECRET  | Random secret for JWT tokens         |
| AI_API_KEY  | OpenAI API key (platform.openai.com) |
