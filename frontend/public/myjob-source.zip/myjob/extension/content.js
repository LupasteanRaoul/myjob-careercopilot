// MyJob Extension - Content Script
// Runs on all pages - minimal footprint, no DOM manipulation

// Badge counter: if we detect a job posting, we could update the extension badge
// Currently passive - just sends page info when popup requests it
